#!/bin/bash



#1. Ayuda
	#Explicacion; Permite que el usuario sepa como usar el script sin ejecutar nada
if [ "$1" == "-help" ]; then
	echo "Uso: $0 [ORIGEN] [DESTINO]"
	exit 0
fi


#2. Definir variables
	#Explicacion: Guardamos los datos en las variables ORIGEN y DESTINO 
	#Explicacion: $1 y $2 son los parametros que el usuario esribe para ejecutar el script
	#Explicaicon: date genera una fecha dinamica para que cada backup se genere con la fecha incluida en el nombre

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE="log_bkp_$FECHA.tar.gz"


#3. Verificar que el usuario ingreso los datos necesarios
	#Explicacion: -d verifica si el directorio existe, evita errores al intentar comprimir algo que no existe
	

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: Debes ingresar el origen y el destino"
	echo "Uso: ./backup_full.sh /ruta/origen /ruta/destino"
	exit 1 
fi

#4. Comprimir los archivos
	#Explicacion: tar es el comando para comprimir, -c crea -z comprime -f define el nombre del archivo

echo "Comprimiento archivos..."
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"

#5. Confirmacion si salio todo ok
	#Explicacion: $? captura el estado del ultimo comando, si es 0 todo funciono perfectamente

if [ "$?" -eq 0 ]; then
	echo "Backup creado con exito, puedes consultarlo en la ruta: $DESTINO/$NOMBRE! "
else
	echo "Hubo un error al crear el backup, intentelo devuelta"
fi

